import TaskTable from "@/components/TaskTable";

export default function Tasks() {
  return (
    <div className="ml-72 mr-4 mt-32">
      <TaskTable />
    </div>
  );
}
