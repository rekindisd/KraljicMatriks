import MatrixForm from "@/components/MatrixForm";

export default function TaskDetail() {
  return (
    <div className="mt-24 ml-[272px] pl-8">
      <MatrixForm />
    </div>
  );
}
