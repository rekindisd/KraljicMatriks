import ProjectTable from "@/components/ProjectTable"

export default function Home() {
  return (
    <div>   
      <ProjectTable/>   
    </div>
  );
}
